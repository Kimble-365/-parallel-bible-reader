Hindi Pilot 1.1

Open SAB Project/Hindi Parallel Pilot/Hindi Parallel Pilot.appDef in Scripture App Builder 14.7+.
Two collections: Hindi original and mechanical Latin transliteration; John chapter 3 only.
The Latin adaptation requires native-speaker review. No recorded audio or timings bundled.
Listen externally: https://live.bible.is/bible/HINDPI/JHN/3
Source and license: USFM and source notes/ABOUT.txt

Browser PWA: https://kimble-365.github.io/-parallel-bible-reader/sab-hindi-pilot/v1.1/app/
The browser build uses the SAB modern PWA MIT template. It is separate from the main reader.
